class City {
  final String name;
  final String country;
  City(this.name, this.country);
}

final List<City> allCities = [
  City("Berlín", "Alemania"),
  City("Múnich", "Alemania"),
  City("Madrid", "España"),
  City("Barcelona", "España"),
  City("Andorra la Vella", "Andorra"),
  City("Londres", "Reino Unido"),
  City("París", "Francia"),
];
