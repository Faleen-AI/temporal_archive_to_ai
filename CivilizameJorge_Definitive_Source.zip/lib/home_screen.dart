import 'package:flutter/material.dart';
import 'game_data.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Civilízame esta Jorge")),
      body: ListView.builder(
        itemCount: allCities.length,
        itemBuilder: (context, index) {
          final city = allCities[index];
          return ListTile(
            title: Text(city.name),
            subtitle: Text(city.country),
            leading: Icon(Icons.location_city),
          );
        },
      ),
    );
  }
}
